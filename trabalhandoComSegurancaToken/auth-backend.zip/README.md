# Auth Backend (Next.js) - Example

## Setup

1. Copy `.env.example` to `.env.local` and adjust DB credentials and JWT_SECRET.
2. Run `npm install`.
3. Run `npm run dev` to start Next.js on port 3000.

## Endpoints

- POST /api/login  { username, password }
- GET  /api/me     (Authorization: Bearer <token>)

