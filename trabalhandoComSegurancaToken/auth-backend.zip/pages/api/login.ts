import type { NextApiRequest, NextApiResponse } from "next";
import { getPool } from "../../../lib/db";
import { comparePassword, signToken } from "../../../lib/auth";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: "username and password required" });

  try {
    const pool = await getPool();
    const result = await pool.request()
      .input("username", username)
      .query("SELECT Id, Username, PasswordHash, FullName FROM dbo.Users WHERE Username = @username");

    const user = result.recordset[0];
    if (!user) return res.status(401).json({ error: "Invalid credentials" });

    const ok = await comparePassword(password, user.PasswordHash);
    if (!ok) return res.status(401).json({ error: "Invalid credentials" });

    const token = signToken({ sub: user.Id, username: user.Username });
    return res.json({ token, user: { id: user.Id, username: user.Username, fullName: user.FullName } });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Server error" });
  }
}
