import type { NextApiRequest, NextApiResponse } from "next";
import { verifyToken } from "../../../lib/auth";
import { getPool } from "../../../lib/db";

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const auth = req.headers.authorization;
  if (!auth) return res.status(401).json({ error: "Missing authorization header" });
  const parts = auth.split(" ");
  if (parts.length !== 2 || parts[0] !== "Bearer") return res.status(401).json({ error: "Invalid authorization header" });

  const token = parts[1];
  try {
    const payload = verifyToken(token) as any;
    const pool = await getPool();
    const result = await pool.request().input("id", payload.sub).query("SELECT Id, Username, FullName FROM dbo.Users WHERE Id = @id");
    const user = result.recordset[0];
    if (!user) return res.status(404).json({ error: "User not found" });
    return res.json({ user });
  } catch (err) {
    console.error(err);
    return res.status(401).json({ error: "Invalid token" });
  }
}
