-- Script to create DB and Users table and insert example user.
CREATE DATABASE AuthDemo;
GO

USE AuthDemo;
GO

CREATE TABLE [dbo].[Users] (
  [Id] INT IDENTITY(1,1) PRIMARY KEY,
  [Username] NVARCHAR(100) NOT NULL UNIQUE,
  [PasswordHash] NVARCHAR(200) NOT NULL,
  [FullName] NVARCHAR(200) NULL,
  [CreatedAt] DATETIME DEFAULT GETDATE()
);
GO

-- Generate a bcrypt hash locally (see README) and replace below.
INSERT INTO [dbo].[Users] (Username, PasswordHash, FullName)
VALUES ('jose', '$2b$10$EXEMPLO_HASH_SUBSTITUIR', 'José Oliveira');
GO
