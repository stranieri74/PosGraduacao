## Gerar hash bcrypt (Node)
Crie um arquivo `gerar-hash.js` com:
```js
const bcrypt = require('bcryptjs');
(async () => {
  const hash = await bcrypt.hash('Senha123!', 10);
  console.log(hash);
})();
```
Rode `node gerar-hash.js` e copie o hash para o `database.sql`.
