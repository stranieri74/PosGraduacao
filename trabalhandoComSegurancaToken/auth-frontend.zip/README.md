# Auth Frontend (Angular) - Example

## Setup

1. `npm install`
2. `npm start` (requires @angular/cli)
3. App expects backend at http://localhost:3000/api

