import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-protected',
  template: '<div style="margin:20px"><h3>Área protegida</h3><pre>{{user | json}}</pre></div>'
})
export class ProtectedComponent implements OnInit {
  user: any;
  constructor(private http: HttpClient) {}
  ngOnInit() {
    this.http.get('http://localhost:3000/api/me').subscribe({
      next: (r:any) => this.user = r.user,
      error: (e) => this.user = { error: 'Não autorizado' }
    });
  }
}
